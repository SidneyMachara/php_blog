<!-- <input type="button" name="like" value="like"class="media_btn"> -->
<div class="num_likes"><?php echo $likes." "; ?> likes</div> <button type="button" name="like" class="media_btn like" >Like</button>

<div class="share_container">
  <h4>Share on:</h4>

  <div class="share_container_btns">
    <ul>
      <li><button type="button" name="like" class="media_btn">facebook</button></li>
      <li><button type="button" name="like" class="media_btn">twitter</button></li>
      <li><button type="button" name="like" class="media_btn">instagram</button></li>
      <li><button type="button" name="like" class="media_btn">somthing</button></li>
    </ul>
  </div>

</div>
