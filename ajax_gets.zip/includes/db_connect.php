<?php
session_start();
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'peace_society_blog';
$conn = mysqli_connect($host,$user,$pass,$db) or die($conn->error);

//-----------------
$_SESSION['already_liked'] = 0;


?>
