<?php
include("includes/db_connect.php");

 ?>
<head>
  <meta charset="utf-8">
  <title></title>
  <meta name="viewport" content="width-device-width, initial-scale=1">
    <!-- temp  choose links to use later-->

  <link rel="stylesheet"  href="bootstrap/css/bootstrap.min.css">
  <script src="bootstrap/js/bootstrap.min.js"></script>
  <script src="css/jquery.js"></script>
  <link rel="stylesheet"  href="css/myStyle.css">


</head>
