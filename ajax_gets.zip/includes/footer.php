<footer class="footer">
  <center>Copyright &copy 2017-<?php echo date("y"); ?> David Sidney Machara </center>
</footer>
