<nav class="nav_outer">
  <div class="nav_content">
<?php include("mobile_nav.php"); ?>
    <ul class="nav_ul">
      <li><a active href="index.php">Dashboard</a></li>
      <li><a href="addPost.php">Add Post</a></li>
      <li><a href="addCategory.php">Add Category</a></li>
      <li><a href="admin.php">Admin</a></li>
      <li><a href="../index.php">Visit Blog</a></li>

    </ul>

    <a href="logout.php" class="logout_btn" ><i class="glyphicon glyphicon-log-out"></i></a>

  </div>


</nav>
